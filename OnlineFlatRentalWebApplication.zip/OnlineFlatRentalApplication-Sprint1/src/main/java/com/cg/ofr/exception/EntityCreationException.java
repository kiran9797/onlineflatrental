package com.cg.ofr.exception;

public class EntityCreationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EntityCreationException(String message) {
		super(message);
	}
	

}
