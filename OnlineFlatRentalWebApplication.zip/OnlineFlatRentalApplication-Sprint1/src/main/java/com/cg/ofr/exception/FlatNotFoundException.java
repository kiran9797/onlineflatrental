package com.cg.ofr.exception;

public class FlatNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public FlatNotFoundException(String message) {
		super(message);

	}

}
