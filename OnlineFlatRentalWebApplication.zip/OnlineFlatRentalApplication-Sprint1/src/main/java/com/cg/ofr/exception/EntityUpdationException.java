package com.cg.ofr.exception;

public class EntityUpdationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EntityUpdationException(String message) {
		super(message);
	}

}
