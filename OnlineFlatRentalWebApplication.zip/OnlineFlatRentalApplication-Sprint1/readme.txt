swagger : http://localhost:8086/swagger-ui.html#
oracle : http://127.0.0.1:8081/apex/f?p=4500:1001:1861818720024800::NO:::
